# Cara membuat APK

Proyek ini membungkus halaman konverter (`app/src/main/assets/index.html`) menjadi aplikasi Android
yang jalan offline. Hasil unduhan disimpan ke folder **Download/Konverter** di HP.

## Cara 1: lewat GitHub (tanpa memasang apa pun)
1. Buat akun GitHub, lalu buat repositori baru (boleh private).
2. Unggah seluruh isi folder proyek ini, **termasuk folder `.github`**.
3. Buka tab **Actions**, pilih **Build APK**, lalu klik **Run workflow**.
4. Tunggu sekitar 3 sampai 6 menit. Buka hasil run-nya, lalu unduh **konverter-apk** di bagian Artifacts.
5. Ekstrak ZIP-nya, kirim `app-debug.apk` ke HP, lalu pasang (izinkan "pasang dari sumber tidak dikenal").

## Cara 2: lewat Android Studio
1. Pasang Android Studio (sudah termasuk JDK 17).
2. **File > Open**, pilih folder proyek ini, lalu tunggu sinkronisasi Gradle selesai (butuh internet sekali).
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Mengubah halaman
Edit `app/src/main/assets/index.html`, lalu bangun ulang APK.

## Catatan
- APK ini bertipe debug, cukup untuk dipakai sendiri. Untuk diunggah ke Play Store perlu APK/AAB release yang ditandatangani.
- Android 9 ke bawah akan meminta izin penyimpanan saat pertama dibuka.
